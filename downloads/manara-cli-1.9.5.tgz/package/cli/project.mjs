// Linux/Node adapter. The browser engine and its limits remain shared.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {Parser, Language} from '../dist/vendor/web-tree-sitter-web-tree-sitter.js';
import {syntaxView} from '../dist/syntax.js';
import {scanFiles, languageFor} from '../dist/scanner.js';
import {MAX_FILE, MAX_TOTAL, MAX_FILES} from '../dist/security.js';

const ignoredDirectories = new Set(['.git', 'node_modules', 'vendor', '.venv', 'venv', '__pycache__', '.next', '.cache', 'coverage', 'build']);
const vendor = fileURLToPath(new URL('../dist/vendor/', import.meta.url));
const grammarFiles = {js:'javascript-tree-sitter-javascript', ts:'typescript-tree-sitter-typescript', tsx:'typescript-tree-sitter-tsx', py:'python-tree-sitter-python', php:'php-tree-sitter-php_only', phpDocument:'php-tree-sitter-php'};
let ready;
const grammars = new Map();
const safeName = name => name.length <= 1024 && !/[\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/u.test(name);

export function collectFiles(target, {exclude = [], output} = {}) {
  const selected = path.resolve(target);
  const selectedStat = fs.lstatSync(selected);
  if (selectedStat.isSymbolicLink()) throw Error('The scan target must not be a symbolic link.');
  if (!selectedStat.isDirectory() && !selectedStat.isFile()) throw Error('Choose a regular file or directory.');
  const root = selectedStat.isDirectory() ? selected : path.dirname(selected);
  const excludedPaths = exclude.map(value => path.resolve(root, value));
  const outputPath = output ? path.resolve(output) : null;
  const files = [], skipped = [], exclusions = [];
  let bytes = 0, entries = 0;
  const relative = full => path.relative(root, full).split(path.sep).join('/');
  const record = (full, reason) => skipped.push({file:safeName(relative(full)) ? relative(full) : '[invalid file name]', reason});
  const excluded = full => excludedPaths.some(item => full === item || full.startsWith(item + path.sep));
  function visit(full, depth = 0) {
    if (++entries > 10000) { if (entries === 10001) record(root, 'entry-limit'); return; }
    if (depth > 32) { record(full, 'depth-limit'); return; }
    if (full === outputPath || excluded(full)) { exclusions.push({file:relative(full), reason:'excluded'}); return; }
    if (!safeName(relative(full))) { record(full, 'invalid-name'); return; }
    let stat;
    try { stat = fs.lstatSync(full); }
    catch { record(full, 'unreadable'); return; }
    if (stat.isSymbolicLink()) { record(full, 'symlink'); return; }
    if (stat.isDirectory()) {
      if (full !== selected && ignoredDirectories.has(path.basename(full))) { exclusions.push({file:relative(full), reason:'default-exclusion'}); return; }
      let directory;
      try {
        directory = fs.opendirSync(full);
        for (let entry; (entry = directory.readSync());) {
          visit(path.join(full, entry.name), depth + 1);
          if (entries > 10000) break;
        }
      } catch { record(full, 'unreadable-directory'); }
      finally { directory?.closeSync(); }
      return;
    }
    if (!stat.isFile()) { record(full, 'not-regular'); return; }
    if (!languageFor(path.basename(full))) { record(full, 'unsupported'); return; }
    if (stat.size > MAX_FILE) { record(full, 'file-size-limit'); return; }
    if (files.length >= MAX_FILES) { record(full, 'file-count-limit'); return; }
    if (bytes + stat.size > MAX_TOTAL) { record(full, 'total-size-limit'); return; }
    let fd;
    try {
      fd = fs.openSync(full, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW | fs.constants.O_NONBLOCK);
      const current = fs.fstatSync(fd);
      if (!current.isFile() || current.dev !== stat.dev || current.ino !== stat.ino) { record(full, 'file-changed'); return; }
      // Bounded read also handles a file growing after the initial stat.
      const buffer = Buffer.alloc(Math.min(MAX_FILE, MAX_TOTAL - bytes) + 1);
      let length = 0, read;
      while (length < buffer.length && (read = fs.readSync(fd, buffer, length, buffer.length - length, null))) length += read;
      if (length > MAX_FILE || bytes + length > MAX_TOTAL) { record(full, 'size-limit'); return; }
      if (buffer.subarray(0, length).includes(0)) { record(full, 'binary'); return; }
      let content;
      try { content = new TextDecoder('utf-8', {fatal:true}).decode(buffer.subarray(0, length)); }
      catch { record(full, 'invalid-utf8'); return; }
      // The shared browser validator counts UTF-8 bytes of decoded source.
      files.push({name:relative(full), content});
      bytes += Buffer.byteLength(content);
    } catch { record(full, 'unreadable'); }
    finally { if (fd !== undefined) fs.closeSync(fd); }
  }
  visit(selected);
  // Stable analysis/report ordering independent of filesystem directory order.
  files.sort((a, b) => a.name.localeCompare(b.name, 'en'));
  if (!files.length) throw Error('No supported readable source files within the scan limits.');
  return {files, skipped, exclusions, bytes};
}

export async function syntaxViews(files) {
  ready ??= Parser.init({wasmBinary:fs.readFileSync(path.join(vendor, 'web-tree-sitter-web-tree-sitter.wasm'))});
  await ready;
  const views = {}, diagnostics = [];
  for (const file of files) {
    let kind = languageFor(file.name);
    if (!['js', 'ts', 'py', 'php'].includes(kind)) continue;
    if (kind === 'ts' && /\.tsx$/i.test(file.name)) kind = 'tsx';
    if (kind === 'php' && /<\?(?:php|=)/i.test(file.content)) kind = 'phpDocument';
    let parser, tree;
    try {
      if (!grammars.has(kind)) grammars.set(kind, await Language.load(fs.readFileSync(path.join(vendor, 'tree-sitter-' + grammarFiles[kind] + '.wasm'))));
      parser = new Parser();
      parser.setLanguage(grammars.get(kind));
      tree = parser.parse(file.content);
      views[file.name] = syntaxView(file.content, tree);
      if (!views[file.name].complete) diagnostics.push({code:'parse-errors', file:file.name});
    } catch { diagnostics.push({code:'parser-unavailable', file:file.name}); }
    finally { tree?.delete(); parser?.delete(); }
  }
  return {views, diagnostics};
}

export async function scanProject(target, options = {}) {
  const input = collectFiles(target, options);
  const syntax = await syntaxViews(input.files);
  const report = scanFiles(input.files, syntax.views);
  report.diagnostics.push(...syntax.diagnostics);
  report.inputReview = {bytes:input.bytes, skipped:input.skipped, excluded:input.exclusions};
  const incomplete = input.skipped.some(item => item.reason !== 'unsupported') || syntax.diagnostics.length;
  if (incomplete && report.scanIntegrity === 'complete') report.scanIntegrity = 'partial';
  report.notes = ['Local read-only scan using the original Manara engine. No source is uploaded.', 'Coverage applies only to the listed files and supported checks. Excluded and unsupported files are not reviewed.'];
  if (input.skipped.length) report.notes.push(`${input.skipped.length} input files or paths skipped; see inputReview.`);
  return report;
}
