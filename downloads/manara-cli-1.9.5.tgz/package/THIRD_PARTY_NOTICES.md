# Bundled parser components

This standalone CLI archive includes the pinned parser runtime and grammars below, obtained from the original Manara project's installed dependencies. The corresponding upstream copyright and MIT license texts are retained in `dist/vendor/*-LICENSE`.

| Component | Version | License |
| --- | --- | --- |
| web-tree-sitter | 0.27.1 | MIT |
| tree-sitter-javascript | 0.25.0 | MIT |
| tree-sitter-typescript | 0.23.2 | MIT |
| tree-sitter-python | 0.25.0 | MIT |
| tree-sitter-php | 0.24.2 | MIT |

This archive does not contain Semgrep, Trivy, Bandit, Gitleaks, Redis/Valkey, the hosted backend or AI models.
