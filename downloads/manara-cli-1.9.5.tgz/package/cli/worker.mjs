import {parentPort, workerData} from 'node:worker_threads';
import {scanProject} from './project.mjs';

try { parentPort.postMessage({report:await scanProject(workerData.target, workerData.options)}); }
catch { parentPort.postMessage({error:'Scan failed. Check the target, read permissions and installed parser assets. No source content was logged.'}); }
