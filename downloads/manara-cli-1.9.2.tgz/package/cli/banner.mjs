// Plain ASCII keeps the lighthouse readable in Linux terminals and saved text.
export const banner = String.raw`
             /\
            /__\
           /____\
          |<(@)>|      M A N A R A
          |_____|      C Y B E R
           |   |
          /|   |\
         / | []| \
        /__|___|__\
     ~~~~~~~~~~~~~~~~~
`;
